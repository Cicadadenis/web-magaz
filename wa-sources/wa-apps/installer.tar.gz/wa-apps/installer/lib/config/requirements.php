<?php

/*
 * This file is part of Webasyst framework.
 *
 * Licensed under the terms of the GNU Lesser General Public License (LGPL).
 * www/framework/license/
 *
 * @link www/
 * @author Webasyst LLC
 * @copyright 2011 Webasyst LLC
 * @package installer
 */

return array(
    'php'                                                                                            => array(
        'strict'  => true,
        'version' => '>=5.6.25',
    ),
    'php.curl'                                                                                       => array(
        'description' => 'Get updates information from update servers',
        'strict'      => false,
    ),
    'phpini.allow_url_fopen'                                                                         => array(
        'description' => 'Get updates information from update servers',
        'strict'      => false,
        'value'       => 1,
    ),
    'php.mbstring'                                                                                   => array(
//	'description'=>'mbstring provides multibyte specific string functions that help you deal with multibyte encodings in PHP',
        'strict' => true,
        'value'  => 1,
    ),
    'phpini.mbstring.func_overload'                                                                  => array(
        'description' => 'Smarty properly work',
        'strict'      => true,
        'value'       => '<2',
    ),
    'rights..|wa-installer|install.php|api.php|wa-log|wa-data/protected|wa-apps|wa-content|wa-cache' => array(
        'description' => 'Check folder rights for install and update',
        'strict'      => true,
    ),

);
